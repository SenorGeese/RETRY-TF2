Edit:
Tis was passed around in pugs.
It's pretty okay/cool mod.