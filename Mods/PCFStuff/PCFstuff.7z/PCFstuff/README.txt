Edited:
These were never really seen these again.
They were really cool but I never got around to using them.
If any of y'all want to try doing this file hunt and install these then go ahead.