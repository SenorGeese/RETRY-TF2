Not my mod. I got this from "https://syampuuh.github.io/mods", Just states:
The No HUD mod, but this will also pull your viewmodel waaay back so that it's off-screen. Perfect for photos. This is an imperfect solution, as bigger weapons may still clip on screen sometimes when moving a lot and you'll still see your hands when getting on a zipline or ledge, but it's the best I can do without anything crashing for now.

This is a VPK mod. You need to decompile and recompile yourself. 
If you are going to mod this in; Use VPKTOOL to decompile and RSPNVPK to recompile to VPKs

Goodluck.