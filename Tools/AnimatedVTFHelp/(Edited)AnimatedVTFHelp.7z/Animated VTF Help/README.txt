Edit:
I used this once. Didn't work out too well but maybe that's because i was dumb.
Anyways here. It does seem useful though, maybe it's of use to you.