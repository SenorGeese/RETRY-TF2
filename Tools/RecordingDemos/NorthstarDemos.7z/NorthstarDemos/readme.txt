Recording Cinematics? In Northstar? 

Yes. Here is how. 4:24 minute video (https://youtu.be/vngAik5oVF4). This video goes over using and installing my Northstar_Cinematics.rar and using all the tools. 

This Northstar_Cinematics.rar is a collection of files and tools that are used for cinematics. Preferrably you have a Xbox controller and a numpad.
Including:
-'build yourself' far viewmodel weapons; 'invisible weapons' from shampooh mod dump
-my personal cinematic autoexec.cfg (thanks to cylas for the 1st version)
-Titanfall2_CameraTools_v103 edited slightly to work with NorthstarLauncher.exe
-lastly an edited (read me for easier installion) NoHudToggle mod.