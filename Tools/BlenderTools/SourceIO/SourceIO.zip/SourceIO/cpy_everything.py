import os
import shutil
from pathlib import Path

cp = [Path(r'C:\Users\MED45\AppData\Roaming\Blender Foundation\Blender\2.92\scripts\addons\SourceIO'),
      Path(r'C:\Users\MED45\AppData\Roaming\Blender Foundation\Blender\3.0\scripts\addons\SourceIO')]

for copy_to in cp:
    for file in Path('.').absolute().rglob('*.py'):
        relative = file.relative_to(Path('.').absolute())
        os.makedirs((copy_to / relative).parent, exist_ok=True)
        shutil.copy(file, copy_to / relative)
        print(file, copy_to / relative)

    for file in Path('.').absolute().rglob('*.dll'):
        relative = file.relative_to(Path('.').absolute())
        os.makedirs((copy_to / relative).parent, exist_ok=True)
        shutil.copy(file, copy_to / relative)
        print(file, copy_to / relative)
    for file in Path('.').absolute().rglob('*.so'):
        relative = file.relative_to(Path('.').absolute())
        os.makedirs((copy_to / relative).parent, exist_ok=True)
        shutil.copy(file, copy_to / relative)
        print(file, copy_to / relative)
    for file in Path('.').absolute().rglob('*.dylib'):
        relative = file.relative_to(Path('.').absolute())
        os.makedirs((copy_to / relative).parent, exist_ok=True)
        shutil.copy(file, copy_to / relative)
        print(file, copy_to / relative)
    for file in Path('.').absolute().rglob('*.pyd'):
        relative = file.relative_to(Path('.').absolute())
        os.makedirs((copy_to / relative).parent, exist_ok=True)
        shutil.copy(file, copy_to / relative)
        print(file, copy_to / relative)
    for file in Path('.').absolute().rglob('*.txt'):
        relative = file.relative_to(Path('.').absolute())
        os.makedirs((copy_to / relative).parent, exist_ok=True)
        shutil.copy(file, copy_to / relative)
        print(file, copy_to / relative)
    for file in Path('.').absolute().rglob('*.png'):
        relative = file.relative_to(Path('.').absolute())
        os.makedirs((copy_to / relative).parent, exist_ok=True)
        shutil.copy(file, copy_to / relative)
        print(file, copy_to / relative)
    for file in Path('.').absolute().rglob('*.blend'):
        relative = file.relative_to(Path('.').absolute())
        os.makedirs((copy_to / relative).parent, exist_ok=True)
        shutil.copy(file, copy_to / relative)
        print(file, copy_to / relative)
