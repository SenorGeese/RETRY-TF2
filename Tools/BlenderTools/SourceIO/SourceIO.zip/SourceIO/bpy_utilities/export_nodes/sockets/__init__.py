from .bodygroup_socket import SourceIOBodygroupSocket
from .object_socket import SourceIOObjectSocket
from .material_socket import SourceIOMaterialSocket
from .skin_socket import SourceIOSkinSocket,SourceIOSkinGroupSocket
from .texture_socket import SourceIOTextureSocket
