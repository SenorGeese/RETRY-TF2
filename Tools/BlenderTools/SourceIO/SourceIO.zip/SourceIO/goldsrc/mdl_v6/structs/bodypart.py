from typing import List

from .model import StudioModel
from ....source_shared.base import Base
from ....utilities.byte_io_mdl import ByteIO


class StudioBodypart(Base):
    def __init__(self):
        self.name = ''
        self.model_count = 0
        self.base = 0
        self.model_offset = 0
        self.models: List[StudioModel] = []

    def read(self, reader: ByteIO):
        self.name = reader.read_ascii_string(64)
        (self.model_count, self.base, self.model_offset) = reader.read_fmt('3i')
        with reader.save_current_pos():
            reader.seek(self.model_offset)
            for _ in range(self.model_count):
                model = StudioModel()
                model.read(reader)
                self.models.append(model)

    def write(self, writer: ByteIO, end_offset):
        writer.write_ascii_string(self.name, length=64)
        writer.write_uint32(len(self.models))
        writer.write_uint32(1)
        writer.write_uint32(end_offset)
        with writer.save_current_pos():
            writer.seek(end_offset)
            for model in self.models:
                model.write(writer,)

