﻿namespace LzhamWrapper
{
    public enum Flush
    {
        NoFlush = 0,
        SyncFlush = 2,
        FullFlush = 3,
        Finish = 4,
        TableFlush = 10
    }
}