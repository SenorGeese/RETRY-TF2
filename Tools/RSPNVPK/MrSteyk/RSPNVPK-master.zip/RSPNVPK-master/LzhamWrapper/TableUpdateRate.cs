﻿namespace LzhamWrapper
{
    public enum TableUpdateRate
    {
        InsanelySlow = 1,
        Slowest = 2,
        Default = 8,
        Fastest = 20
    }
}
